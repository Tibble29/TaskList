import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import TaskList from "./Tasklist";
  
var destination = document.querySelector("#container");
  
ReactDOM.render(
    <div>
        <TaskList />
    </div>,
    destination
);