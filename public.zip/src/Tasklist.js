import React, { Component } from "react";
import TaskListItems from "./TaskListItems";
import "./TaskList.css";


class TaskList extends Component {
    constructor(props) {
        super(props);
       
        this.state = {
          items: []
        };
       
        this.addItem = this.addItem.bind(this);
      }


      render() {
        return (
          <div className="TaskListMain">
            <div className="header">
              <form onSubmit={this.addItem}>
                <textarea ref={(a) => this._inputElement = a} 
                        placeholder="enter task">
                </textarea>
                <div class="buttons">
                    <button className="priority low">Low</button> <button className="priority medium">Medium</button> <button className="priority high">High</button>
                </div>
                <br />
                <button className="submit" type="submit">+</button>
              </form>
            </div>
            <TaskListItems entries={this.state.items}/>
          </div>
        );
      } v

      addItem(e) {
        if (this._inputElement.value !== "") {
          var newItem = {
            text: this._inputElement.value,
            key: Date.now(),
            priority: this._inputpriority.value,

          };
       
          this.setState((prevState) => {
            return { 
              items: prevState.items.concat(newItem) 
            };
          });
         
          this._inputElement.value = "";
        }
         
        console.log(this.state.items);
           
        e.preventDefault();
      }
    }


export default TaskList;
