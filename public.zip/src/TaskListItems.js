import React, { Component } from "react";

class TaskListItems extends Component {
  createTasks(item) {
    return <li key={item.key}>{item.text} <a href="">
    <span className="done"></span></a></li>
  }
 
  render() {
    var TaskListEntries = this.props.entries;
    var listItems = TaskListEntries.map(this.createTasks);
 
    return (
      <ul className="theList">
          {listItems}
      </ul>
    );
  }
};
 
export default TaskListItems;